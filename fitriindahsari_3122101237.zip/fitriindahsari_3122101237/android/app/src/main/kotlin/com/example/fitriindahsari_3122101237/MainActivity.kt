package com.example.fitriindahsari_3122101237

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
